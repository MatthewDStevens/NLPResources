from maze import Maze
from polarmaze import PolarMaze
from tasks.__init__ import *